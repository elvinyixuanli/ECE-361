
public class MyThread implements Runnable {

	int thread_number;
	
	//constructor
	public MyThread(int thread_num) {
		this.thread_number=thread_num;
	}
	
	@Override
	public void run() {
		System.out.println("helllo from thread: "+ thread_number);
		MainClass.from_threads=thread_number;
	}

}
