import java.util.Scanner;



 class MainClass {

	 public static int from_threads;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("how many thread?: ");
		Scanner sc=new Scanner(System.in);
		int no_threads=sc.nextInt();
		
		for (int i=0;i<no_threads;i++)
		{
			Thread thread=new Thread(new MyThread(i));
			thread.start();
		}
		
		System.out.println("end of main. : "+from_threads);
	}

}
